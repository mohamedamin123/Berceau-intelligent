import time
from gpiozero import OutputDevice
from reseaux.Firebase import Firebase


class Ventilateur:
    def __init__(self, pin: int, vitesse: float, tmp_souhaite: float, mode: str = "Auto", name: str = "Ventilateur", etat: bool = False):
        """
        Initialise un ventilateur avec ses paramètres de configuration.

        :param pin: Numéro de la broche GPIO utilisée.
        :param vitesse: Vitesse initiale du ventilateur (0.0 à 1.0).
        :param tmp_souhaite: Température souhaitée en °C.
        :param mode: Mode de fonctionnement ("Auto" ou "Manuel").
        :param name: Nom du ventilateur.
        :param etat: État initial du ventilateur (allumé ou éteint).
        """
        self.pin = pin
        self.name = name
        self.etat = etat
        self.vitesse = vitesse
        self.tmp_souhaite = tmp_souhaite
        self.mode = mode
        self.ventilateur = OutputDevice(pin, active_high=False)  # Use OutputDevice with active_high=False
        self.vitesse_actuelle = 0.0  # État initial : éteint
        self.previous_data = None
        self.initialiser()

    def initialiser(self) -> None:
        """Initialise le ventilateur sur la broche donnée."""
        try:
            self.ventilateur.off()  # Initialize as off
            print(f"{self.name} initialisé sur la broche GPIO {self.pin}.")
        except Exception as e:
            print(f"Erreur lors de l'initialisation du ventilateur : {e}")

    def change_mode(self) -> None:
        """Change le mode entre 'Auto' et 'Manuel'."""
        self.mode = "Manuel" if self.mode == "Auto" else "Auto"
        print(f"Mode changé en {self.mode}.")
        if self.mode == "Auto":
            self.vitesse_actuelle = self.calcul_vitesse_auto()  # Calculer la vitesse automatique
        self.modifier_vitesse(self.vitesse_actuelle)

    def regler_tmp_souhaite(self, tmp: float) -> None:
        """Règle la température souhaitée."""
        self.tmp_souhaite = tmp
        print(f"{self.name} température souhaitée réglée à {self.tmp_souhaite}°C.")
        if self.mode == "Auto":
            self.vitesse_actuelle = self.calcul_vitesse_auto()  # Recalculer la vitesse en mode Auto
            self.modifier_vitesse(self.vitesse_actuelle)

    def arreter(self):
        """Arrête le ventilateur."""
        self.vitesse_actuelle = 0.0
        self.etat = False
        self.ventilateur.off()  # Use off method for OutputDevice
        print(f"{self.name} éteint.")

    def demarrer(self):
        """Allume le ventilateur."""
        if not self.etat:
            self.vitesse_actuelle = 1.0  # Valeur maximale pour démarrer
            self.etat = True
            self.ventilateur.on()  # Use on method for OutputDevice
            print(f"{self.name} démarré.")
        else:
            print(f"{self.name} est déjà en marche.")

    def modifier_vitesse(self, nouvelle_vitesse: float) -> None:
        """
        Modifie la vitesse du ventilateur.

        :param nouvelle_vitesse: Valeur entre 0.0 (éteint) et 1.0 (vitesse max).
        """
        if 0.0 <= nouvelle_vitesse <= 1.0:
            self.vitesse_actuelle = nouvelle_vitesse
            # Note: OutputDevice doesn't control speed like PWMOutputDevice, so this is just for controlling on/off
            if self.vitesse_actuelle == 0.0:
                self.ventilateur.off()
            else:
                self.ventilateur.on()
            print(f"{self.name} vitesse modifiée à {nouvelle_vitesse}.")
        else:
            print("Erreur : La vitesse doit être comprise entre 0.0 et 1.0.")

    def calcul_vitesse_auto(self) -> float:
        """Calcule la vitesse en fonction de la température souhaitée en mode automatique."""
        if self.tmp_souhaite < 20:
            return 0.2  # Faible vitesse
        elif 20 <= self.tmp_souhaite < 25:
            return 0.5  # Moyenne vitesse
        else:
            return 1.0  # Haute vitesse

    def envoyerDonne(self, token,chemin):
        """Envoie l'état actuel du ventilateur à Firebase."""
        try:
            data = {
                "etat": self.etat,
                "mode": self.mode,
                "tmpSouhaite": self.tmp_souhaite,
                "vitesse": self.vitesse_actuelle,
            }
            if data != self.previous_data:
                Firebase.send_data(chemin, data, token)
                self.previous_data = data
                print(f"État envoyé à Firebase : {data}")
            else:
                print("Aucune modification à envoyer.")
        except Exception as e:
            print(f"Erreur lors de l'envoi de l'état à Firebase : {e}")

    def recevoirDonne(self, token,chemin):
        """Récupère l'état actuel du ventilateur depuis Firebase et met à jour l'état et la vitesse du ventilateur."""
        try:
            # Récupération des données depuis Firebase
            data = Firebase.get_data(chemin, token)
            
            if data:
                self.etat = data["etat"]
                self.mode = data["mode"]
                self.tmp_souhaite = data["tmpSouhaite"]
                self.vitesse_actuelle = data["vitesse"]

                if self.mode == 'Auto':
                    self.vitesse_actuelle = self.calcul_vitesse_auto()  # Calcule la vitesse en mode auto
                else:
                    if self.etat:
                        self.demarrer()
                    else:
                        self.arreter()

                self.modifier_vitesse(self.vitesse_actuelle)
            else:
                print("Aucune donnée reçue depuis Firebase.")
        except Exception as e:
            print(f"Erreur lors de la réception de l'état de {self.name} depuis Firebase : {e}")
